from .fastcap import *

__doc__ = fastcap.__doc__
if hasattr(fastcap, "__all__"):
    __all__ = fastcap.__all__